package com.example.demo.data.dto

data class UserDto(

        val id: Long,

        val name: String,

        val age: Int
)