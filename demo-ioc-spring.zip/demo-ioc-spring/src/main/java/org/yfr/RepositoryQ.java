package org.yfr;

public class RepositoryQ implements Repository {

    @Override
    public String findName() {
        return "QQ Chan";
    }
}
