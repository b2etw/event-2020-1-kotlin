package org.yfr;

public interface Service {

    String findName();
}
