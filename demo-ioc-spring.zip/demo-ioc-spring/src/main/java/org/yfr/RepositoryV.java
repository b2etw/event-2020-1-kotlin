package org.yfr;

public class RepositoryV implements Repository {

    @Override
    public String findName() {
        return "Vincent Huang";
    }
}
