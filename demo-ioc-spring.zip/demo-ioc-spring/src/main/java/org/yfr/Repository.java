package org.yfr;

public interface Repository {

    String findName();
}
